#!/bin/bash
# $Id: avs.sh 5 2007-07-27 12:44:16Z pkun $

echo `gettext "# Testing correct DrWev antivirus"`

# Global test result (default = 0 : ok)
export GLOBALRES=0

export TMPFILE="/tmp/mactests_file"
export RESFILE="/tmp/mactests_res"

VERBOSE=
while getopts v OPTION
do
case $OPTION in
    v) VERBOSE=yes ;;
esac
done


drweb-ctl -h 1>: 2>:

if [[ $? -eq 0 ]]; then
       echo `gettext "Dr.Web is installed"` 1>&2
else
        echo `gettext "Can't run Dr.Web"` 1>&2
	GLOBALRES=1
fi



echo 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' >$TMPFILE

echo `gettext "# Try scan test virus, if it wasn't detected by file-checker"` 1>&2
drweb-ctl scan $TMPFILE

echo `gettext "# Get ID of test virus from quarantine... "` 1>&2
sleep 1
IDS_EICAR=$(drweb-ctl quarantine | grep -B1 -i $TMPFILE | grep ID: | awk '{print $2}')

if [ -n "$IDS_EICAR" ]; then
    echo -n `gettext "# Viruses found in quarantine..."` 1>&2
    echo `gettext "PASS"` 1>&2
    echo `gettext "# Remove test viruses from quarantine "` 1>&2
    for id in $IDS_EICAR; do
        drweb-ctl quarantine --Delete  $id
    done
else
    echo  `gettext "# Viruses not detected in quarantine..."` 1>&2
    IDS_EICAR=$(drweb-ctl threats | grep -B1 -i $TMPFILE | grep ID: | awk '{print $2}')
    if [ -n "$IDS_EICAR" ]; then
        echo -n `gettext "# Viruses detected..."` 1>&2
        echo `gettext "PASS"` 1>&2
    	echo `gettext "# Remove test viruses from threats"` 1>&2
    	for id in $IDS_EICAR; do
		echo `gettext $id` 1>&2
        	drweb-ctl threats --Delete  $id
    	done
    else
    	echo -n `gettext "Viruses not detected..."` 1>&2
    	echo `gettext "FAIL"` 1>&2
        GLOBALRES=1
    fi
fi


# Remove testing environment
rm -f $TMPFILE $RESFILE
export TMPFILE
export RESFILE

exit $GLOBALRES
