#!/bin/bash
# $Id: afick.sh 5 2018-06-29 12:44:16Z pkun $

echo `gettext "# Testing correct integrity control by afick"`

# Global test result (default = 0 : ok)
export GLOBALRES=0

export TMPFILE="/tmp/mactests_file"
TESTDBM="/tmp/test_afick.dbm"
CONF="/tmp/test_afick.conf"

VERBOSE=
while getopts v OPTION
do
case $OPTION in
    v) VERBOSE=yes ;;
esac
done


echo 'some' >$TMPFILE

echo `gettext "Create test afick config"` 1>&2
cat /etc/afick.conf | grep -v '^[/|'\'']' >$CONF
echo $TMPFILE >>$CONF

echo `gettext "Create hash database for test integrity of file"` 1>&2
afick -i -c $CONF -D $TESTDBM

if [[ $? -eq 0 ]]; then
       echo `gettext "Afick is successful run"` 1>&2
else
        echo `gettext "Can't run afick"` 1>&2
        GLOBALRES=1
fi

echo `gettext "Make changes in test file and check it"` 1>&2
echo '123' >>$TMPFILE
RES=$(afick -k -c $CONF -D $TESTDBM 2>/dev/null | grep -v '^[#]' | grep '^[changed|new|deleted]' | sort -u | awk '{print $1 " " $4}')
echo $RES

if [ -n "$RES" ]; then
    echo -n `gettext "All work..."` 1>&2
    echo `gettext "PASS"` 1>&2
else
    echo -n `gettext "Changes not detected..."` 1>&2
    echo `gettext "FAIL"` 1>&2
    GLOBALRES=1
fi

# Remove testing environment
rm -f $TMPFILE $TESTDBM $CONF
export TMPFILE

exit $GLOBALRES
