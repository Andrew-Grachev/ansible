#ifndef SOBOL_LIB_H
#define SOBOL_LIB_H

#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef unsigned char  UCHAR;
typedef unsigned short USHORT;
typedef unsigned long  ULONG;
typedef long           LONG;
typedef LONG*          PLONG;
typedef UCHAR  BYTE;
typedef USHORT WORD;
typedef ULONG  DWORD;
typedef int SNCODE;

typedef uint8_t UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;

#define SN_OK           0	/* Операция выполнена успешно                       */
#define SNHW_ERROR      1	/* Нет драйвера поддержки (только для NT)           */
#define SNHW_NOCARD     2	/* Отсутствует плата ЭЗ в компьютере                */
#define SNHW_BADUSER    3	/* Текущий пользователь не является администратором */
#define SNHW_BADINPUT   4	/* Неправильные входные параметры                   */
#define SNHW_BADSIZE    5	/* Неправильный размер передаваемых данных          */
#define SNHW_CARDERROR  6	/* Ошибка аппаратуры                                */
#define SNHW_BADOP      7	/* Ошибка выполнения команды                        */
#define SNHW_NOTM       8	/* ТМ не прижата                                    */
#define SN_ACCESS	-1	/* Недостаточно прав для доступа к файлу            */
#define SN_NOMEM	-2	/* Ошибка распределения памяти                      */
#define SN_NOTIMPL	-3	/* Не поддерживается или не реализовано             */

#define MEMORY_BANK_SIZE 32768 // Размер банка памяти в байтах
#define SBL_BOARD_INFO_STRUCT_SIGNATURE 0x52564253

#define SBL_WORK_EX_STRUCT_SIGNATURE    0x58454F57

/// Версия структуры с информацией о плате
#define SBL_BOARD_INFO_VER_1                          1
/// Текущая версия структуры с информацией о плате
#define SBL_BOARD_INFO_CURRENT_VERSION         SBL_BOARD_INFO_VER_1

/// Флаг, показывающий, что это программный Соболь
#define SBL_BOARD_INFO_FLAG_BIOS        1

/// Флаг, показывающий, что Соболь работает в автономном режиме
#define SBL_BOARD_INFO_WORKFLAG_SECURE                1
/// Для шифрования используется ГОСТ 2015
#define SBL_BOARD_INFO_WORKFLAG_CRYPTO2015            2
/// Признак наличия расширенного заголовка
#define SBL_BOARD_INFO_WORKFLAG_HAVE_WORK_EX   4

#pragma pack(1)
typedef struct _SBL_BOARD_INFO
{
        UINT32  dwSignature;            //<! Сигнатура SBL_BOARD_INFO_STRUCT_SIGNATURE
        UINT8   byStructVersion;        //<! Версия структуры
        UINT32  dwFlags;                //<! Флаги (SBL_BOARD_INFO_FLAG_xxxx).
        UINT8   byProdMajor;            //<! Старший байт версии прошивки
        UINT8   byProdMinor;            //<! Младший байт версии прошивки
        UINT16  wBuildMajor;            //<! Старший word номера билда
        UINT16  wBuildMinor;            //<! Младший word номера билда
        UINT8   byFpgaBuildMajor;       //<! Старший байт версии прошивки ПЛИС
        UINT8   byFpgaBuildMinor;       //<! Младший байт версии прошивки ПЛИС
        UINT32  dwEepromBank0Size;      //<! Размер используемой памяти в банке 0 (не включает байты в конце, которые
                                                                //<! Используются для работы со сторожевым таймером)
        UINT32  dwEepromBank1Size;      //<! Размер используемой памяти в банке 1
        UINT32  dwFlashSize;            //<! Размер микросхемы памяти Flash для прошивки
        UINT8   Reserved[3];            //<! Зарезервировано. Выравнивание до 32 байт.
} SBL_BOARD_INFO, *PSBL_BOARD_INFO;
#pragma pack()


/* операции с реле */
enum {
    SWOP_GET_STATUS = 1,	/* получить состояние */
    SWOP_SHORT,			/* реле замкнуто      */
    SWOP_OPEN			/* реле разомкнуто    */
};

/* информация об устройстве. на практике структура не используется */
typedef struct _TYPE_INFO_DEVICE
{
    short			Type;
    unsigned short	Size;
    unsigned long	Port;
    unsigned short	NameLength;
    char			Name[ 1 ];
} TYPE_INFO_DEVICE, *PTYPE_INFO_DEVICE;

#if ( __GNUC__ == 2)
#pragma pack(1)
#else
#pragma pack(push,1)
#endif
/* версия платы */

typedef struct _VERSION_INFO
{
    BYTE	Major;				/* старшая часть версии  */
    BYTE	Minor;				/* младшая часть версии  */
    WORD	Build;				/* версия билда прошивки */
} VERSION_INFO, *PVERSION_INFO;
#if ( __GNUC__ == 2)
#else
#pragma pack(pop)
#endif

typedef enum _TYPE_TM
{
    ExternalTm,				/* внешняя "таблетка" iButton                       */
    InternalTm,				/* внутренняя "таблетка" iButton. не используется   */
    Memory0,				/* нулевой банк EEPROM                              */
    Memory1					/* первый банк EEPROM                               */
} TYPE_TM, *PTYPE_TM;

/*
 *	Function name  : sbisCard
 *	Description    : Позволяет проверить наличие платы ЭЗ в компьютере
 *	Parameters     : нет
 *	Return values  : код ошибки. SN_OK означает, что плата установлена и модуль ядра загружен
 *	Remarks        :
 *	Date           : 04.07.2008
 *	Author         : Sergey V. Shubin
*/
SNCODE sbisCard(void);

/*
 *	Function name  : sbGetRand
 *	Description    : Возвращает случайные данные, полученные с аппаратного датчика случайных чисел
 *	Parameters     : Buffer - адрес буфера, BufferSize - размер буфера
 *	Return values  : код ошибки. SN_OK - данные прочитаны, SNHW_ERROR - отсутствует файл устройства /dev/sobol
 *	Remarks        :
 *	Date           : 04.07.2008
 *	Author         : Sergey V. Shubin
*/
SNCODE sbGetRand(void * Buffer, unsigned long BufferSize);

/*
 *	Function name  : sbGetVersion
 *	Description    : Возвращает версию платы
 * 	Parameters     : pVerInfo - указатель на структуру, куда будет записана версия.
 * 	Return values  : код ошибки. SN_OK - версия успешно прочитана
 *	Remarks        : Особенность работы:
 *
 *	Date           : 11.07.2008
 *	Author         : Sergey V. Shubin
 */
SNCODE sbGetVersion(PVERSION_INFO pVerInfo);

/*
 *  Function name  : sbisAdmin
 *  Description    : Позволяет проверить тип пользователя. На практике - это проверка, доступна ли
 *                 : защищенная память платы.
 *  Parameters     : нет
 *  Return values  : код ошибки. SN_OK - в систему вошел администратор
 *  Remarks        :
 *  Date           : 14.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbisAdmin(void);

/*
 *  Function name  : TestRand
 *  Description    : Позволяет проверить датчик случайный чисел. Состоит из пpоцедуpы
 *                 : получения данных из ДСЧ и оценки паpаметpов pаспpеделения и
 *                 : пpоцедуpы пpовеpки pезультатов на допустимость
 *  Parameters     : нет
 *  Return values  : код ошибки. SN_OK - тест прошел успешно
 *  Remarks        :
 *  Date           : 04.02.2009
 *  Author         : Igor V. Lavrega
*/
SNCODE TestRand(void);

/*
 *  Function name  : sbReadID
 *  Description    : Читает серийный номер электронного идентификатора
 *  Parameters     : TypeTm - должно быть равно ExternalTm
 *                 : Buffer - буфер, в который будет помещен серийный номер
 *                 : BufferSize - размер буфера
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 14.07.2008
 /  Author         : Sergey V. Shubin
*/
SNCODE sbReadID(TYPE_TM TypeTm, void* Buffer, unsigned long BufferSize);

/*
 *  Function name  : sbReadMem
 *  Description    : Читает память платы или электронного идентификатора
 *  Parameters     : TypeTm - откуда читать (из таблетки или из памяти)
 *                 : Buffer - адрес буфера, в который прочитать данные
 *                 : BufferSize - размер буфера
 *                 : Offset - смещение в памяти
 *                 : ReadLength - указатель на переменную, в которую будет положен размер считанной информации
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 14.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbReadMem(TYPE_TM TypeTm, void* Buffer, unsigned long BufferSize, unsigned long Offset, unsigned long* ReadLength);

/*
 *  Function name  : sbWriteMem
 *  Description    : Пишет в память платы или электронного идентификатора
 *  Parameters     : TypeTm - куда писать (в таблетку или в память)
 *                 : Buffer - адрес буфера, из которого брать данные
 *                 : BufferSize - размер буфера
 *                 : Offset - смещение в памяти
 *                 : WriteLength - указатель на переменную, в которую будет положен размер записанной информации
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 14.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbWriteMem(TYPE_TM TypeTm, void* Buffer, unsigned long BufferSize, unsigned long Offset, unsigned long* WriteLength);

/*
 *  Function name  : sbReadConfiguration
 *  Description    : Функция не реализована, не надо ее использовать
 *  Parameters     : Buffer - буфер для данных
 *                 : BufferSize - размер буфера
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 29.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbReadConfiguration(PTYPE_INFO_DEVICE Buffer, unsigned long BufferSize);

/*
 *  Function name  : sbLockMem
 *  Description    : Закрывает доступ к нулевому банку EEPROM платы
 *  Parameters     : нет
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 14.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbLockMem();

/*
 *  Function name  : sbOperateSwitch
 *  Description    : Получение и установка состояния реле на плате
 *  Parameters     : SwitchNo - номер реле, с которым будем работать
 *                 : pSwState - указатель на переменную с состоянием реле
 *                 : если на входе в *pSwState лежит значение SWOP_GET_STATUS, будет возвращено состояние реле (в виде
 *                 : SWOP_SHORT или SWOP_OPEN). Если на входе в *pSwState лежит значение SWOP_SHORT или SWOP_OPEN,
 *                 : реле будет установлено в соответствующее состояние
 *  Return values  : код ошибки
 *  Remarks        :
 *
 *  Date           : 30.07.2008
 *  Author         : Sergey V. Shubin
*/
SNCODE sbOperateSwitch(ULONG SwitchNo, PLONG pSwState);

/*
 *  Function name  : sbReadTmNoVerify
 *  Description    : Читает память электронного идентификатора без верификации
 *                 : для корректного чтения изменяющихся регистров TM
 *  Parameters     : Buffer - адрес буфера, в который прочитать данные
 *                 : BufferSize - размер буфера
 *                 : Offset - смещение в памяти
 *                 : ReadLength - указатель на переменную, в которую будет записан размер считанной информации
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 05.12.2018
 *  Author         : Igor N. Ivanov
*/
SNCODE sbReadTmNoVerify(void* Buffer, unsigned long BufferSize, unsigned long Offset,
                        unsigned long* ReadLength);

/*
 *  Function name  : sbWriteTmProtectedMem
 *  Description    : Функция для записи protected битов в TM
 *  Parameters     : Buffer - адрес буфера, в который прочитать данные
 *                 : BufferSize - размер буфера
 *                 : Offset - смещение в памяти
 *                 : WriteLength - указатель на переменную, в которую будет записан размер записанной информации
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 06.12.2018
 *  Author         : Igor N. Ivanov
*/
SNCODE sbWriteTmProtectedMem(void* Buffer, unsigned long BufferSize, unsigned long Offset,
                             unsigned long* WriteLength);

/*
 *  Function name  : sbGetVersionSobol4
 *  Description    : Функция возвращает информацию о плате в формате Соболь 4
 *  Parameters     : pSblBoardInfo - указатель на структуру, куда будет записана информация о плате.
 *  Return values  : код ошибки
 *  Remarks        :
 *  Date           : 11.12.2019
 *  Author         : Igor N. Ivanov
*/
SNCODE sbGetVersionSobol4(PSBL_BOARD_INFO pSblBoardInfo);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* SOBOL_LIB_H */
